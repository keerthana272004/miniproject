
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

abstract class GuestFeedback {
    private String guestName;
    private String feedbackText;
    private int rating;

    public GuestFeedback(String guestName, String feedbackText, int rating) {
        this.guestName = guestName;
        this.feedbackText = feedbackText;
        this.rating = rating;
    }

    public String getGuestName() {
        return guestName;
    }

    public String getFeedbackText() {
        return feedbackText;
    }

    public int getRating() {
        return rating;
    }
}

class CustomerFeedback extends GuestFeedback {
	

    private String customerService;
    private String livingFacilities;
    private String foodService;
    
    public CustomerFeedback(String guestName, String feedbackText, int rating, String customerService,
                            String livingFacilities, String foodService) {
        super(guestName, feedbackText, rating);
        this.customerService = customerService;
        this.livingFacilities = livingFacilities;
        this.foodService = foodService;
    }

    public String getCustomerService() {
        return customerService;
    }

    public String getLivingFacilities() {
        return livingFacilities;
    }

    public String getFoodService() {
        return foodService;
    }
}

 class feed {
    private static final String DB_URL = "jdbc:mysql://localhost/hotel_feedback";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "sdkeerthana272004";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter your name:");
        String guestName = sc.nextLine();
        System.out.println("How was the customer service (Good, better, bad):");
        String customerService = sc.nextLine();
        System.out.println("How was the Living facilities (Good, better, bad):");
        String livingFacilities = sc.nextLine();
        System.out.println("How was the Food Experience (Good, better, bad):");
        String foodService = sc.nextLine();
        System.out.println("Please enter your Feedback:");
        String feedbackText = sc.nextLine();
        System.out.println("Please enter the rating:");
        int rating = sc.nextInt();

        CustomerFeedback customerFeedback = new CustomerFeedback(guestName, feedbackText, rating,
                customerService, livingFacilities, foodService);
        saveFeedbackToDatabase(customerFeedback);

        System.out.println(" ");
        System.out.println("Name: " + customerFeedback.getGuestName() + ", " +
                "Customerservice: " + customerFeedback.getCustomerService() + ", " +
                "Living Facilities: " + customerFeedback.getLivingFacilities() + ", " +
                "Food Experience: " + customerFeedback.getFoodService() + ", " +
                "Feedback: " + customerFeedback.getFeedbackText() + ", " +
                "Rating: " + customerFeedback.getRating() + ".");
    }

    private static void saveFeedbackToDatabase(CustomerFeedback customerFeedback) {
        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO guest_feedback (guest_name, customer_service, living_facilities, food_service, feedback_text, rating) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, customerFeedback.getGuestName());
            preparedStatement.setString(2, customerFeedback.getCustomerService());
            preparedStatement.setString(3, customerFeedback.getLivingFacilities());
            preparedStatement.setString(4, customerFeedback.getFoodService());
            preparedStatement.setString(5, customerFeedback.getFeedbackText());
            preparedStatement.setInt(6, customerFeedback.getRating());
            preparedStatement.executeUpdate();
            System.out.println("Feedback saved successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}